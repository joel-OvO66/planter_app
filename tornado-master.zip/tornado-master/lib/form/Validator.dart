import 'package:flutter/cupertino.dart';

class Validator {

  static ValidatorFn? customize(FormFieldValidator<dynamic>? fn) {
    return ValidatorFn('customize', fn!);
  }

  static ValidatorFn? idCardNo() {
    return ValidatorFn('idCardNo', (value) {
      return _isCardId(value!);
    });
  }

  static ValidatorFn? email() {
    RegExp regExp = new RegExp(r'^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$');
    return ValidatorFn('email', (value) {
      return regExp.hasMatch(value!) ? null : "邮箱格式有误";
    });
  }

  static ValidatorFn? phone([dynamic value]) {
    RegExp regExp = new RegExp(r'^1(3[0-9]|4[014-9]|5[0-35-9]|6[2567]|7[0-8]|8[0-9]|9[0-35-9])\d{8}$');
    return ValidatorFn('phone', (value) {
      return regExp.hasMatch(value!) ? null : "手机号码格式有误";
    });
  }

  static ValidatorFn? isNumber([dynamic value]) {
    RegExp regExp = new RegExp(r'^[0-9]*$');
    return ValidatorFn('isNumber', (value) {
      return regExp.hasMatch(value!) ? null : "必须填入整数数字";
    });
  }

  static ValidatorFn? isDoubleNumber([dynamic value]) {
    RegExp regExp = new RegExp(r'^[0-9]+(.[0-9]{1,2})?$');
    return ValidatorFn('isDoubleNumber', (value) {
      return regExp.hasMatch(value!) ? null : "必须为数字，位数不得超过两位";
    });
  }

  /**
   * 精确到小数点后三位
   */
  static ValidatorFn? isDoubleNumberForLength([dynamic value]) {
    RegExp regExp = new RegExp(r'^[0-9]+(.[0-9]{1,3})?$');
    return ValidatorFn('isDoubleNumberForLength', (value) {
      return regExp.hasMatch(value!) ? null : "必须为数字，位数不得超过三位";
    });
  }

  static ValidatorFn? pattern(String source, [dynamic value]) {
    RegExp regExp = new RegExp(source);
    return ValidatorFn('pattern', (value) {
      return regExp.hasMatch(value!) ? null : "格式有误";
    });
  }

  static ValidatorFn? required() {
    return ValidatorFn('required', (value) {
      if (value == null) {
        return " 不能为空";
      } else if (value is String){
        return value.trim().length > 0 ? null : "不能为空";
      } else {
        return null;
      }
    });
  }

  static ValidatorFn? maxLength(int maxLength) {
    return ValidatorFn('maxLength', (value) {
      return value!.trim().length > maxLength ? "长度不能超过$maxLength" : null;
    });
  }

  static ValidatorFn? minLength(int minLength) {
    return ValidatorFn('minLength', (value) {
      return value!.trim().length < minLength ? "长度不能少于$minLength" : null;
    });
  }

  static ValidatorFn? min(int min) {
    return ValidatorFn('min', (value) {
      try {
        int v = int.parse(value!);
        return v < min ? "不能低于$min" : null;
      } on Exception {
        return null;
      }
    });
  }

  static ValidatorFn? max(int max) {
    return ValidatorFn('max', (value) {
      try {
        int v = int.parse(value!);
        return v > max ? "不能高于$max" : null;
      } on Exception {
        return null;
      }
    });
  }

  static ValidatorFn? doubleMin(int min) {
    return ValidatorFn('doubleMin', (value) {
      try {
        double v = double.parse(value!);
        return v < min ? "不能低于$min" : null;
      } on Exception {
        return null;
      }
    });
  }

  static ValidatorFn? doubleMax(double max) {
    return ValidatorFn('doubleMax', (value) {
      try {
        double v = double.parse(value!);
        return v > max ? "不能高于$max" : null;
      } on Exception {
        return null;
      }
    });
  }

  static String? _isCardId(String cardId) {
    if (cardId.length != 18) {
      return "身份证长度不够"; // 位数不够
    }
    // 身份证号码正则
    RegExp postalCode = new RegExp(
        r'^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|[Xx])$');
    // 通过验证，说明格式正确，但仍需计算准确性
    if (!postalCode.hasMatch(cardId)) {
      return "格式不正确";
    }
    //将前17位加权因子保存在数组里
    final List idCardList = ["7", "9", "10", "5", "8", "4", "2", "1", "6", "3", "7", "9", "10", "5", "8", "4", "2"];
    //这是除以11后，可能产生的11位余数、验证码，也保存成数组
    final List idCardYArray = ['1', '0', '10', '9', '8', '7', '6', '5', '4', '3', '2'];
    // 前17位各自乖以加权因子后的总和
    int idCardWiSum = 0;

    for (int i = 0; i < 17; i++) {
      int subStrIndex = int.parse(cardId.substring(i, i + 1));
      int idCardWiIndex = int.parse(idCardList[i]);
      idCardWiSum += subStrIndex * idCardWiIndex;
    }
    // 计算出校验码所在数组的位置
    int idCardMod = idCardWiSum % 11;
    // 得到最后一位号码
    String idCardLast = cardId.substring(17, 18);
    //如果等于2，则说明校验码是10，身份证号码最后一位应该是X
    if (idCardMod == 2) {
      if (idCardLast != 'x' && idCardLast != 'X') {
        return "身份证校验不通过";
      }
    } else {
      //用计算出的验证码与最后一位身份证号码匹配，如果一致，说明通过，否则是无效的身份证号码
      if (idCardLast != idCardYArray[idCardMod]) {
        return "身份证校验不通过";
      }
    }
    return null;
  }

}

class ValidatorFn {

  final String type;

  final FormFieldValidator<dynamic> fn;

  ValidatorFn(this.type, this.fn){}

  String? call(dynamic value) {
    return fn(value);
  }
}
