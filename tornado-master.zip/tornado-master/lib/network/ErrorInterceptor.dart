import 'package:dio/dio.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../tornado.dart';
import 'ErrorResponse.dart';

class ErrorInterceptor extends Interceptor {
  @override
  void onError(DioError error, ErrorInterceptorHandler handler) {
    print(error);
    print('======>请求错误的url：${error.response?.data}');
    //判读异常状态  401未登录过期或者未登录状态的异常
    if (error.response != null) {
      Response response = error.response!;
      String msg = response.statusMessage ?? "";
      String type = "error";
      dynamic responseData = error.response!.data;
      switch (response.statusCode) {
        case 400:
          msg = '请求错误(400)';
          if (responseData!=null) {
            if (responseData is String) {
              msg = responseData;
            } else if (responseData is Map<String,dynamic>) {
              ErrorResponse errorResponse=ErrorResponse.fromJson(responseData );
              msg = errorResponse.message ?? "";
            }
          }
          break;
        case 401:
          type = 'warning';
          msg = '未授权，请重新登录(401)';
          error.response?.statusCode == 401;
          //获取本地存储的Token
          SharedPreferences.getInstance().then((value) {
            String? token = value.getString(BaseConstants.ACCESS_TOKEN);
            if (token != null && token.trim() != '') {
              //Token存在则说明Token过期需要刷新，否则是未登录状态不做处理
              // Dio dio = HttpService.instance.dio!; //获取应用的Dio对象进行锁定  防止后面请求还是未登录状态下请求
              // dio.lock();
              // String accessToken = await getToken(); //重新获取Token
              // dio.unlock();
              // if (accessToken != '') {
              //   Dio tokenDio2 = new Dio(HttpService.instance!.dio!.options); //创建新的Dio实例
              //   var request = error.requestOptions;
              //   request.headers['Authorization'] = 'JWT $accessToken';
              //   // var response = await tokenDio2.request(request.path,
              //   //     data: request.data, queryParameters: request.queryParameters, cancelToken: request.cancelToken, options: request, onReceiveProgress: request.onReceiveProgress);
              // }
            }
          });
          break;
        case 403:
          msg = '拒绝访问(403)';
          break;
        case 404:
          msg = '访问资源不存在(404)';
          break;
        case 408:
          msg = '请求超时(408)';
          break;
        case 500:
          msg = "服务器内部错误";
          break;
        case 501:
          msg = '服务未实现(501)';
          break;
        case 502:
          msg = '网络错误(502)';
          break;
        case 503:
          msg = '服务不可用(503)';
          break;
        case 504:
          msg = '网络超时(504)';
          break;
        case 505:
          msg = 'HTTP版本不受支持(505)';
          break;
        case 0:
          msg = '无法连接到服务器，请检测您的网络';
          break;
        default:
          msg = "连接出错  !";
      }
      if(msg!=""){
        Fluttertoast.showToast(msg: msg);
      }
    }
    super.onError(error, handler);
  }

  Future<String> getToken() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    //获取当前的refreshToken，一般后台会在登录后附带一个刷新Token用的reToken
    // String? refreshToken =   prefs.getString(Constants.REFRESH_TOKEN);
    //因为App单例的Dio对象已被锁定，所以需要创建新的Dio实例
    // Dio tokenDio = new Dio(HttpService.instance!.dio!.options);
    // Map<String, String> map = {
    //   "rft": refreshToken,
    // }; //设置当前的refreshToken
    try {
      //发起请求，获取Token
      // var response = await tokenDio.post("/api/v1/user/refresh_token", data: map);
      // if (response.statusCode == 201) {
      // LoginBean loginbean = LoginBean.fromJson(response.data);
      // SharedPreferencesUtil.putData(Constants.ACCESS_TOKEN, loginbean.data.token);
      // if (loginbean.data.rft != null && loginbean.data.rft.trim() != '') {
      //   SharedPreferencesUtil.putData(Constants.REFRESH_TOKEN, loginbean.data.rft);
      // }
      // return loginbean.data.token;
      // }
      return '';
    } on DioError catch (e) {
      print("Token刷新失败:$e");
      prefs.setString(BaseConstants.ACCESS_TOKEN, '');
      // SharedPreferencesUtil.putData(Constants.REFRESH_TOKEN, '');
      return '';
    }
  }
}
